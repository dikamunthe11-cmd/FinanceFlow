# FinanceFlow V2 (Firebase online sync)

Versi web dashboard team: Firebase Auth login, realtime Firestore sync, transaksi bersama, role-based delete (admin), filters, charts, export CSV.

## A. Buat project Firebase
1. Firebase Console: https://console.firebase.google.com/ → Create project.
2. Project overview → Add app → Web app → register. Copy Firebase config.
3. Authentication → Sign-in method → enable Email/Password.
4. Authentication → Users → Add user untuk buat akun team.
5. Firestore Database → Create database (production mode).
6. Firestore → Rules, paste isi file `firestore.rules` → Publish.

## B. Masukkan konfigurasi
Buka `app.js`, ganti nilai `firebaseConfig` placeholder (`YOUR_API_KEY`, `YOUR_PROJECT`, dst) dengan Web app config Firebase Anda.

## C. Atur role Admin
1. Authentication → Users → pilih akun admin, salin UID.
2. Firestore Database → buat collection `users`, document ID = UID admin.
3. Isi field `role` (string) = `admin`.
4. Akun team lain dapat dibuat di Authentication Users; bila tidak memiliki dokumen `users/{uid}` atau role bukan admin, default aplikasi `user`.

Admin dapat menghapus transaksi. Pengguna biasa dapat melihat semua transaksi dan membuat transaksi. Role admin diatur manual di console, tidak dapat diubah melalui website.

## D. Deploy GitHub Pages
1. Upload seluruh file ke repository GitHub (root).
2. Settings → Pages → Deploy from a branch → `main` → `/ (root)` → Save.
3. Pastikan Firebase Authentication → Settings → Authorized domains, tambahkan domain GitHub Pages Anda (misalnya `username.github.io`).
4. Buka URL GitHub Pages.

## Files
- `index.html`, `style.css`, `app.js`
- `firestore.rules` (rules keamanan)
- `README.md`

## Catatan keamanan
- Jangan commit service-account key atau secret server.
- Firebase Web config bukan secret; Rules menentukan akses.
- Rules mengizinkan semua pengguna login membaca transaksi dan membuat transaksi mereka sendiri; admin menghapus dan mengubah transaksi.
- Role admin hanya dapat diatur melalui Firebase Console.
- Dashboard ini tidak memiliki audit log/approval workflow.
- Firestore rules mencegah user non-admin menghapus transaksi; admin dapat menghapus. Editing transaksi tidak disediakan UI.
